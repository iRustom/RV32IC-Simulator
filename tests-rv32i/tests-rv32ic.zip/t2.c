/* Type your code here, or load an example. */
#include "services.h"
int main() {
    int x = 10;
    int y = 20;
    x = x + 2*y - 13;
    printInt(x);
    return 1;
}
